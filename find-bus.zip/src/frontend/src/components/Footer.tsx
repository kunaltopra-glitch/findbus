import { Link } from "@tanstack/react-router";
import { Bus, Mail, MapPin, Phone } from "lucide-react";
import { SiInstagram, SiLinkedin, SiX, SiYoutube } from "react-icons/si";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/find-bus", label: "Find Bus" },
  { href: "/book-ticket", label: "Book Ticket" },
  { href: "/ai-bot", label: "AI Bot" },
  { href: "/customer-support", label: "Customer Support" },
];

const SOCIAL_LINKS = [
  {
    icon: SiInstagram,
    href: "https://instagram.com",
    label: "Instagram",
    color: "hover:text-pink-400",
  },
  {
    icon: SiLinkedin,
    href: "https://linkedin.com",
    label: "LinkedIn",
    color: "hover:text-blue-400",
  },
  {
    icon: SiX,
    href: "https://x.com",
    label: "X (Twitter)",
    color: "hover:text-sky-400",
  },
  {
    icon: SiYoutube,
    href: "https://youtube.com",
    label: "YouTube",
    color: "hover:text-red-400",
  },
];

export function Footer() {
  const year = new Date().getFullYear();
  const hostname =
    typeof window !== "undefined" ? window.location.hostname : "";

  return (
    <footer className="bg-[oklch(0.14_0.08_264)] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Grid */}
        <div className="py-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 border-b border-white/10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-lg bg-[oklch(0.72_0.21_50)] flex items-center justify-center">
                <Bus className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-display font-bold text-xl tracking-tight">
                  Find<span className="text-[oklch(0.82_0.18_55)]">Bus</span>
                </span>
                <p className="text-[oklch(0.6_0.04_250)] text-[10px] tracking-wider uppercase leading-none">
                  Haryana Roadways
                </p>
              </div>
            </div>
            <p className="text-[oklch(0.65_0.03_250)] text-sm font-body leading-relaxed">
              Real-time bus tracking powered by AI and GPS simulation for
              Haryana Roadways passengers.
            </p>
            {/* Social Icons */}
            <div className="flex gap-3 mt-5">
              {SOCIAL_LINKS.map(({ icon: Icon, href, label, color }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className={`w-9 h-9 rounded-lg bg-white/8 flex items-center justify-center text-[oklch(0.65_0.03_250)] ${color} transition-colors hover:bg-white/15`}
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display font-semibold text-sm uppercase tracking-widest text-[oklch(0.82_0.18_55)] mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2.5">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-sm text-[oklch(0.65_0.03_250)] hover:text-white transition-colors font-body"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Routes */}
          <div>
            <h3 className="font-display font-semibold text-sm uppercase tracking-widest text-[oklch(0.82_0.18_55)] mb-4">
              Popular Routes
            </h3>
            <ul className="space-y-2.5">
              {[
                "Rohtak → Hisar",
                "Gurugram → Chandigarh",
                "Panipat → Delhi",
                "Ambala → Karnal",
                "Faridabad → Rewari",
              ].map((route) => (
                <li key={route}>
                  <span className="text-sm text-[oklch(0.65_0.03_250)] font-body">
                    {route}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-display font-semibold text-sm uppercase tracking-widest text-[oklch(0.82_0.18_55)] mb-4">
              Contact Us
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-[oklch(0.72_0.21_50)] mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm text-white font-body">1800-180-2345</p>
                  <p className="text-xs text-[oklch(0.55_0.03_250)] font-body">
                    Toll Free (24×7)
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-[oklch(0.72_0.21_50)] mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm text-white font-body">
                    support@findbus.hr.gov.in
                  </p>
                  <p className="text-xs text-[oklch(0.55_0.03_250)] font-body">
                    Mon–Sat, 9AM–6PM
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[oklch(0.72_0.21_50)] mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm text-white font-body">
                    HRTC Head Office
                  </p>
                  <p className="text-xs text-[oklch(0.55_0.03_250)] font-body">
                    Bus Stand Road, Rohtak – 124001
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-[oklch(0.5_0.03_250)] font-body text-center sm:text-left">
            © {year}. Designed By{" "}
            <span className="text-[oklch(0.72_0.18_55)] font-semibold">
              Kunal Pandit
            </span>
            . Built with <span className="text-[oklch(0.72_0.21_50)]">♥</span>{" "}
            using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(hostname)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[oklch(0.6_0.05_250)] hover:text-[oklch(0.75_0.1_250)] transition-colors"
            >
              caffeine.ai
            </a>
          </p>
          <div className="flex items-center gap-4 text-xs text-[oklch(0.5_0.03_250)] font-body">
            <span>Privacy Policy</span>
            <span className="w-1 h-1 rounded-full bg-white/20" />
            <span>Terms of Service</span>
            <span className="w-1 h-1 rounded-full bg-white/20" />
            <span>RTI</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
